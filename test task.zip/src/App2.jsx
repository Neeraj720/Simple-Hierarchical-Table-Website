import React, { useState } from 'react';

const initialData = {
    rows: [
        {
            id: "electronics",
            label: "Electronics",
            value: 1400,
            children: [
                { id: "phones", label: "Phones", value: 800 },
                { id: "laptops", label: "Laptops", value: 700 },
            ],
        },
        {
            id: "furniture",
            label: "Furniture",
            value: 1000,
            children: [
                { id: "tables", label: "Tables", value: 300 },
                { id: "chairs", label: "Chairs", value: 700 },
            ],
        },
    ],
};

const App2 = () => {
    const [data, setData] = useState(initialData);

    const updateValue = (id, newValue) => {
        const updatedRows = updateRows(data.rows, id, newValue);
        setData({ rows: updatedRows });
    };

    const updateRows = (rows, id, newValue) => {
        return rows.map(row => {
            if (row.id === id) {
                const variance = ((newValue - row.value) / row.value) * 100;
                const updatedRow = { ...row, value: newValue, variance };
                return updatedRow;
            }
            if (row.children) {
                const updatedChildren = updateRows(row.children, id, newValue); //updatedRow
                const newTotal = updatedChildren.reduce((sum, child) => sum + child.value, 0);
                const variance = ((newTotal - row.value) / row.value) * 100;
                return { ...row, children: updatedChildren, value: newTotal, variance };
            }

            return row;
        });
    };

    const handlePercentageAllocation = (row, percentage) => {
        console.log(row ,"row")
        console.log(percentage ,"percentage")
        const newValue = row.value + (row.value * (percentage / 100));
        console.log(newValue,"new value")
        updateValue(row.id, newValue);
    };

    const handleValueAllocation = (row, newValue) => {
        updateValue(row.id, newValue);
    };

    const renderRows = (rows) => {
        return rows.map(row => (
            <React.Fragment key={row.id}>
                <tr>
                    <td>{row.label}</td>
                    <td>{row.value.toFixed(2)}</td>
                    <td>
                        <input type="number" id={`input-${row.id}`} />
                    </td>
                    <td>
                        <button onClick={() => {
                            const percentage = parseFloat(document.getElementById(`input-${row.id}`).value);
                            if (!isNaN(percentage)) handlePercentageAllocation(row, percentage);
                        }}>Allocation %</button>
                    </td>
                    <td>
                        <button onClick={() => {
                            const value = parseFloat(document.getElementById(`input-${row.id}`).value);
                            if (!isNaN(value)) handleValueAllocation(row, value);
                        }}>Allocation Val</button>
                    </td>
                    <td>{row.variance ? `${row.variance.toFixed(2)}%` : '0%'}</td>
                </tr>
                {row.children && renderRows(row.children)}
            </React.Fragment>
        ));
    };

    const grandTotal = data.rows.reduce((sum, row) => sum + row.value, 0);

    return (
        <div>
            <h1>Hierarchical Table</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Label</th>
                        <th>Value</th>
                        <th>Input</th>
                        <th>Allocation %</th>
                        <th>Allocation Val</th>
                        <th>Variance %</th>
                    </tr>
                </thead>
                <tbody>
                    {renderRows(data.rows)}
                    <tr>
                        <td><strong>Grand Total</strong></td>
                        <td><strong>{grandTotal.toFixed(2)}</strong></td>
                        <td colSpan="4"></td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};

export default App2;