import React, { useState } from 'react'

function App() {
  const initialData =
  {
    "rows": [
      {
        "id": "electronics",
        "label": "Electronics",
        "value": 1400, //this value needs to be calculated from the children values (800+700)
        "children": [
          {
            "id": "phones",
            "label": "Phones",
            "value": 800
          },
          {
            "id": "laptops",
            "label": "Laptops",
            "value": 700
          }
        ]
      },
      {
        "id": "furniture",
        "label": "Furniture",
        "value": 1000, //this need to be calculated from the children values (300+700)
        "children": [
          {
            "id": "tables",
            "label": "Tables",
            "value": 300
          },
          {
            "id": "chairs",
            "label": "Chairs",
            "value": 700
          }
        ]
      }
    ]
  }
  const [value, setValue] = useState(0)
  const [data,setData] = useState(initialData)
  console.log(value)
  const handleAllocation = (row, percentage) => {
    const newValue = row.value + (row.value * (percentage / 100));
    updateValue(row.id,newValue)
  }

  const updateValue = (id,newValue)=>{
    const updateRows = updateRow(data.rows,id,newValue)
    // setData({rows:updateRows})
  }

  const updateRow = (rows,id,newValue) =>{
    // console.log("rows",rows)
    // console.log("id",id)
    console.log("newValue",newValue)


    return rows.map((row)=>{
      if(row.children){
        const updatedChildren = updateRows(row.children, id, newValue);
        console.log(updatedChildren ,"updated children")
      }
    })
  }
  return (
    <>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">lable</th>
            <th scope="col">value</th>
            <th scope="col">input</th>
            <th scope="col">allocation %</th>
            <th scope="col">allocation val</th>
            <th scope="col">variance %</th>
          </tr>
        </thead>
        <tbody>
          {
            data.rows.map((row) => {
              return <>
                <tr key={row.id}>
                  <td>{row.label}</td>
                  <td>{row.value}</td>
                  <td>
                    <input type="number" onChange={(e) => setValue(e.target.value)} />
                  </td>
                  <td>
                    <button className='btn btn-success' onClick={() => handleAllocation(row, value)}>Allocation%</button>
                  </td>
                  <td>
                    <button className='btn btn-danger'>Allocation val</button>
                  </td>
                  <td>0%</td>
                </tr>
                {
                  row.children.map((child) => {
                    return <>
                      <tr>
                        <td>{child.label}</td>
                        <td>{child.value}</td>
                        <td>
                          <input type="number" onChange={(e) => setValue(e.target.value)}  />
                        </td>
                        <td>
                          <button className='btn btn-success' onClick={() => handleAllocation(child, value)}>Allocation%</button>
                        </td>
                        <td>
                          <button className='btn btn-danger'>Allocation val</button>
                        </td>
                        <td>0%</td>
                      </tr>
                    </>
                  })
                }
              </>
            })
          }
        </tbody>
      </table>
    </>
  )
}

export default App




